#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

#include <stdlib.h>
#include <string>
#include <fstream>
#include <sstream>
#include <ctime>
//#include <iostream>

#include "tmp/soapH.h"
#include "tmp/BBBGpsSoap.nsmap"

/* baudrate settings are defined in <asm/termbits.h>, which is
   included by <termios.h> */
#define BAUDRATE B9600   // Change as needed, keep B

/* change this definition for the correct port */
#define MODEMDEVICE "/dev/ttyO1" //Beaglebone Black serial port

#define _POSIX_SOURCE 1 /* POSIX compliant source */

#define FALSE 0
#define TRUE 1
#define SLEEP 60

void EnviaGps(std::string CAMION,std::string Linea,std::string pasajeros);
double ToGrados(double Coordenada);
std::string GetPasajeros();
std::string GetDate();
void ConectaWebServer(std::string Camion,std::string Count,double Lat,double Lon);
void AbreConexion();

struct soap soap;
main()
{
    int fd, c, res,count,countpas;
    std::string pasajeros;
    std::string CAMION;
    //estas lineas llen el archivo del camion para proporcionar el id
    std::ifstream myfile("/etc/weon/CAMION");
    getline(myfile,CAMION);
    myfile.close();
    //---------------------------------------inicia web server
    AbreConexion();
    //-----------------------------------------------
    count=SLEEP-1;
    countpas=count;
    pasajeros=GetPasajeros();
    struct termios oldtio, newtio;
    char buf[255];
    std::string gps;
    
    // Load the pin configuration
    //int ret = system("echo uart1 > /sys/devices/bone_capemgr.9/slots");
    /* Open modem device for reading and writing and not as controlling tty
       because we don't want to get killed if linenoise sends CTRL-C. */
    fd = open(MODEMDEVICE, O_RDWR | O_NOCTTY );
    if (fd < 0) { perror(MODEMDEVICE); exit(-1); }

    bzero(&newtio, sizeof(newtio)); /* clear struct for new port settings */

    /* BAUDRATE: Set bps rate. You could also use cfsetispeed and cfsetospeed.
       CRTSCTS : output hardware flow control (only used if the cable has
                 all necessary lines. See sect. 7 of Serial-HOWTO)
       CS8     : 8n1 (8bit,no parity,1 stopbit)
       CLOCAL  : local connection, no modem contol
       CREAD   : enable receiving characters */
    newtio.c_cflag = BAUDRATE | CRTSCTS | CS8 | CLOCAL | CREAD;

    /* IGNPAR  : ignore bytes with parity errors
       otherwise make device raw (no other input processing) */
    newtio.c_iflag = IGNPAR;

    /*  Raw output  */
    newtio.c_oflag = 0;

    /* ICANON  : enable canonical input
       disable all echo functionality, and don't send signals to calling program */
    newtio.c_lflag = ICANON;
    /* now clean the modem line and activate the settings for the port */
    tcflush(fd, TCIFLUSH);
    tcsetattr(fd,TCSANOW,&newtio);
    // NMEA command to ouput all sentences
    // Note that this code & format values in manual are hexadecimal
    write(fd, "$PTNLSNM,273F,01*27\r\n", 21);
    /* terminal settings done, now handle input*/
    while (TRUE) {     /* loop continuously */
        /*  read blocks program execution until a line terminating character is
            input, even if more than 255 chars are input. If the number
            of characters read is smaller than the number of chars available,
            subsequent reads will return the remaining chars. res will be set
            to the actual number of characters actually read */
        res = read(fd, buf, 255);
        buf[res] = 0;             /* set end of string, so we can printf */
        gps=buf;
        if(gps.find("RMC")==3)
        {
            count++;
            countpas++;
            if(countpas==SLEEP*5)
            {
                countpas=0;
                pasajeros=GetPasajeros();
            }
            if(count==SLEEP)
            {
                count=0;
                EnviaGps(CAMION,gps,pasajeros);
                //printf("%s",gps.c_str());
                //printf("%s", buf, res);
            }
        }
    }
    tcsetattr(fd, TCSANOW, &oldtio);
}
void EnviaGps(std::string CAMION,std::string Linea,std::string pasajeros)
{
    std::string myline;
    std::stringstream stringaux(Linea);
    double latitud;
    double longitud;
    double velocidad;
    int i=0;
    char *endptr;
    while(getline(stringaux,myline,','))
    {
        //printf("%s \n",myline.c_str());
        switch(i)
        {
            case 3: latitud=atof(myline.c_str());
            case 5: longitud=atof(myline.c_str());
            case 7: velocidad=atof(myline.c_str());              
        }
        i++;
    }
    if(velocidad>1)//en productivo debe ser mayor a uno
    {
        latitud=ToGrados(latitud);
        longitud=ToGrados(longitud);
        try
        {
            printf("llamo al webserver");
            ConectaWebServer(CAMION,pasajeros,latitud,longitud);
        }
        catch(int e)
        {
            printf("Error de envio");
        }
        
    }
    
    printf("Latitud: %f|Longitud: %f|Velocidad: %f\n",latitud,longitud,velocidad);
    
}

double ToGrados(double Coordenada)
{
    int parte_entera;
    double grados;    
    grados=Coordenada/100;
    parte_entera=(int)grados;
    grados=grados-parte_entera;
    grados=100*grados/60;
    grados=grados+parte_entera;
    return grados;
}
std::string GetPasajeros()
{
    std::string pasajeros;
    std::ifstream myfile("/etc/weon/CurrentPasCount");
    getline(myfile,pasajeros);
    myfile.close();
    return pasajeros;
}
std::string GetDate()
{
    std::string Fecha="";
    std::string auxf;
    std::stringstream Y,M,D,H,m;
    time_t now=time(0);
    tm *ltm=localtime(&now);
    Y<<(ltm->tm_year)+1900;
    Fecha=Y.str();
    
    M<<(ltm->tm_mon)+1;
    auxf="0"+M.str();
    Fecha=Fecha+auxf.substr(auxf.length()-2);
    
    D<<ltm->tm_mday;
    auxf="0"+D.str();
    Fecha=Fecha+auxf.substr(auxf.length()-2)+" ";
    
    H<<ltm->tm_hour;
    auxf="0"+H.str();
    Fecha=Fecha+auxf.substr(auxf.length()-2)+":";
        
    m<<ltm->tm_min;
    auxf="0"+m.str();
    Fecha=Fecha+auxf.substr(auxf.length()-2);
    std::cout<<"Fecha: "<<Fecha<<"\n";
    
    return Fecha;
}
void ConectaWebServer(std::string Camion,std::string Count,double lat,double lon)
{
    std::string pwd="weonrules";
    std::string Fecha;
    Fecha=GetDate();
    _ns1__SendCoordenatesResponse respuesta;
    
    _ns1__SendCoordenates parametros;
    parametros.Latitud=lat;
    parametros.Longitud=lon*-1;
    parametros.Camion=&Camion;
    parametros.FechaHora=&Fecha;
    parametros.Pasajeros=&Count;
    parametros.Pwd=&pwd;
    parametros.soap=&soap;
    if(soap_call___ns1__SendCoordenates(&soap,/*el nombre del procedimiento se encuentra en soapClient.c*/
                                        NULL, /*end point*/
                                        NULL, /*soapAction*/
                                        &parametros,
                                        &respuesta
                                        )==SOAP_OK)
        printf("OK\n");
    else
        printf("error\n");
}
void AbreConexion()
{
    soap_init(&soap);
}