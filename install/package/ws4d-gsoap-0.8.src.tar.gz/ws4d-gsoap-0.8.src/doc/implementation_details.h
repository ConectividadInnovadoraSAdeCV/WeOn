/*! \page details Implementation details of WS4D-gSOAP
 *
 * \section messageDispatching Message dispatching
 *
 * TODO
 *
 */
