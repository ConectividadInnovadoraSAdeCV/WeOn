/*
 * soapdefs.h
 *
 *  Created on: 16.06.2009
 *      Author: elmex
 */

#ifndef SOAPDEFS_H_
#define SOAPDEFS_H_

#ifdef WITH_NOIO
#include "alt_io.h"
#endif

#endif /* SOAPDEFS_H_ */
