#ifndef WITH_NOGLOBAL
#define WITH_NOGLOBAL
#endif
#include "hostingServer.c"
#include "hostingClient.c"
