#ifndef WITH_NOGLOBAL
#define WITH_NOGLOBAL
#endif
#include "targetServer.c"
#include "targetClient.c"
