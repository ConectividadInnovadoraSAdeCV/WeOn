/* WS4D-gSOAP - Implementation of the Devices Profile for Web Services
 * (DPWS) on top of gSOAP
 * Copyright (C) 2007 University of Rostock
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA
 *
 *  Created on: 15.01.2010
 *      Author: elmex
 */

#include "ws4d_misc.h"

struct ws4d_qname *
ws4d_qname_alloc (int count, ws4d_alloc_list * alist)
{
  struct ws4d_qname *result = NULL;

  /* test parameters */
  ws4d_assert (alist && (count > 0), NULL);

  result = ws4d_malloc_alist (count * sizeof (struct ws4d_qname), alist);

  if (result)
    {
      WS4D_INIT_LIST (&result->list);
    }

  return result;
}

void
ws4d_qname_free (struct ws4d_qname *qname)
{
  ws4d_assert (qname,);

  if (qname->name)
    {
      ws4d_free_alist (qname->name);
    }

  if (qname->ns)
    {
      ws4d_free_alist (qname->ns);
    }

  if (qname->prefix)
    {
      ws4d_free_alist (qname->prefix);
    }

  ws4d_free_alist (qname);

  return;
}

static int
ws4d_qname_parse (char *string, struct ws4d_qname *qname,
                  ws4d_alloc_list * alist)
{
  char *id;

  ws4d_assert (string && qname && alist, WS4D_ERR);

  if (string[0] == '\"')
    {
      id = strstr (string, "\":");
    }
  else
    {
      id = strchr (string, ':');
    }

  if (id)
    {
      char *prefix;

      prefix = ws4d_malloc_alist (id - string + 1, alist);
      if (!prefix)
        return WS4D_EOM;

      if (string[0] == '\"')
        {
          memcpy (prefix, string + 1, id - string - 1);
          prefix[id - string] = '\0';
        }
      else
        {
          memcpy (prefix, string, id - string);
          prefix[id - string] = '\0';
        }

      if (string[0] == '\"')
        {
          qname->ns = prefix;
          id += 2;
        }
      else
        {
          qname->prefix = prefix;
          id += 1;
        }

      qname->name = ws4d_strdup (id, alist);

      return WS4D_OK;
    }

  return WS4D_ERR;
}

char *
ws4d_qname_tostring2 (struct ws4d_qname *qname, char *buffer, size_t size)
{
  ws4d_assert (qname && buffer && (size > 0), NULL);

  if ((strlen (qname->ns) + (strlen (qname->name)) + 4) > size)
    {
      return NULL;
    }
  else
    {
      memset (buffer, 0, size);
      strcat (buffer, "\"");
      strcat (buffer, qname->ns);
      strcat (buffer, "\"");
      strcat (buffer, ":");
      strcat (buffer, qname->name);

      return buffer;
    }

  return NULL;
}

struct ws4d_qname *
ws4d_qname_dup (struct ws4d_qname *src, ws4d_alloc_list * alist)
{
  struct ws4d_qname *result = NULL;
  int err;

  /* test parameters */
  ws4d_assert (src && alist, NULL);

  /* alloc qname */
  result = ws4d_qname_alloc (1, alist);
  ws4d_fail (!result, NULL);

  /* update name */
  err = ws4d_strdup2 (src->name, (const char **) &result->name, alist);
  ws4d_fail (err != WS4D_OK, NULL);

  /* update namespace */
  err = ws4d_strdup2 (src->ns, (const char **) &result->ns, alist);
  ws4d_fail (err != WS4D_OK, NULL);

  /* update prefix */
  err = ws4d_strdup2 (src->prefix, (const char **) &result->prefix, alist);
  ws4d_fail (err != WS4D_OK, NULL);

  return result;
}

int
ws4d_qnamelist_init (ws4d_qnamelist * head)
{
  /* test parameters */
  ws4d_assert (head, WS4D_EPARAM);

  WS4D_INIT_LIST (head);

  return WS4D_OK;
}

int
ws4d_qnamelist_done (ws4d_qnamelist * head)
{
  /* test parameters */
  ws4d_assert (head, WS4D_EPARAM);

  WS4D_INIT_LIST (head);

  return WS4D_OK;
}

int
ws4d_qnamelist_add (struct ws4d_qname *qname, ws4d_qnamelist * head)
{
  /* test parameters */
  ws4d_assert (qname && head, WS4D_EPARAM);

  ws4d_list_add_tail (&qname->list, head);

  return WS4D_OK;
}

int
ws4d_qnamelist_addstring (const char *string, ws4d_qnamelist * head,
                          ws4d_alloc_list * alist)
{
  char **qname_list = NULL, **temp = NULL;

  /* test parameters */
  ws4d_assert (string && head && alist, WS4D_EPARAM);

  qname_list = ws4d_xsdList_to_Array (string, alist);
  temp = qname_list;

  while (*temp)
    {
      if (*temp)
        {
          struct ws4d_qname *type;

          type = ws4d_qname_alloc (1, alist);
          if (ws4d_qname_parse (*temp, type, alist) == WS4D_OK)
            {
              ws4d_qnamelist_add (type, head);
            }
          else
            {
              ws4d_qname_free (type);
            }

        }
      temp++;
    }

  ws4d_free_xsdArray (qname_list);

  return WS4D_OK;
}

int
ws4d_qnamelist_copy (ws4d_qnamelist * src, ws4d_qnamelist * dst,
                     ws4d_alloc_list * alist)
{
  register struct ws4d_qname *qname, *next;

  /* test parameters */
  ws4d_assert (src && dst && alist, WS4D_EPARAM);

  ws4d_list_foreach (qname, next, src, struct ws4d_qname, list)
  {
    if (qname->ns && qname->name)
      {
        struct ws4d_qname *qname_dup = NULL;
        int res = 0;

        qname_dup = ws4d_qname_dup (qname, alist);
        ws4d_fail (!qname_dup, WS4D_ERR);

        res = ws4d_qnamelist_add (qname_dup, dst);
        ws4d_fail (res != WS4D_OK, res);
      }
  }

  return WS4D_OK;
}

int
ws4d_qnamelist_remove (struct ws4d_qname *qname)
{
  /* test parameters */
  ws4d_assert (qname, WS4D_EPARAM);

  ws4d_list_del (&qname->list);

  return WS4D_OK;
}

int
ws4d_qnamelist_clear (ws4d_qnamelist * head)
{
  register struct ws4d_qname *qname, *next;

  /* test parameters */
  ws4d_assert (head, WS4D_EPARAM);

  ws4d_list_foreach (qname, next, head, struct ws4d_qname, list)
  {
    ws4d_qnamelist_remove (qname);
    ws4d_free_alist (qname);
  }

  return WS4D_OK;
}

int
ws4d_qnamelist_empty (ws4d_qnamelist * head)
{
  return ws4d_list_empty (head);
}

char *
ws4d_qnamelist_tostring (ws4d_qnamelist * head, ws4d_alloc_list * alist)
{
  register struct ws4d_qname *qname, *next;
  char *result = NULL;
  int qname_count = 0, length = 0, i = 0;

  /* test parameters */
  ws4d_assert (head && alist, NULL);

  ws4d_list_foreach (qname, next, head, struct ws4d_qname, list)
  {
    if (qname->ns && qname->name)
      {
        qname_count++;
        length++;
        length += strlen (qname->ns) + 4;
        length += strlen (qname->name);
      }
  }

  if (qname_count < 1)
    return NULL;

  result = ws4d_malloc_alist (length + 1, alist);
  result[0] = '\0';

  i = 0;
  ws4d_list_foreach (qname, next, head, struct ws4d_qname, list)
  {
    if (qname->ns && qname->name)
      {
        strcat (result, "\"");
        strcat (result, qname->ns);
        strcat (result, "\"");
        strcat (result, ":");
        strcat (result, qname->name);
        if ((qname_count > 1) && (i < (qname_count - 1)))
          {
            strcat (result, " ");
          }
        i++;
      }
  }

  return result;
}

char **
ws4d_qnamelist_toarray (ws4d_qnamelist * head, ws4d_alloc_list * alist)
{
  char **noresult = { NULL }, **result = NULL;
  register struct ws4d_qname *qname, *next;
  int qname_count = 0, i = 0;

  /* test parameters */
  ws4d_assert (head && alist, noresult);

  ws4d_list_foreach (qname, next, head, struct ws4d_qname, list)
  {
    if (qname->ns && qname->name)
      {
        qname_count++;
      }
  }

  if (qname_count < 1)
    return noresult;

  result = ws4d_alloc_xsdArray (qname_count + 1, alist);

  if (result)
    {
      i = 0;
      ws4d_list_foreach (qname, next, head, struct ws4d_qname, list)
      {
        if (qname->ns && qname->name)
          {
            int length = 0;

            length += strlen (qname->ns);
            length += strlen (qname->name);
            length += 4;

            result[i] = ws4d_malloc_alist (length + 1, alist);

            strcat (result[i], "\"");
            strcat (result[i], qname->ns);
            strcat (result[i], "\":");
            strcat (result[i], qname->name);

            i++;
          }
      }
    }

  result[qname_count] = NULL;

  return result;
}
